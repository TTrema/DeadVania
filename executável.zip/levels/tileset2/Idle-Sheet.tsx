<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Idle-Sheet" tilewidth="16" tileheight="16" tilecount="80" columns="16">
 <image source="../../graphics/Legacy-Fantasy - High Forest 2.3/Character/Idle/Idle-Sheet.png" width="256" height="80"/>
</tileset>
