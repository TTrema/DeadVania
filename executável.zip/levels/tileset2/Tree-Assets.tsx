<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Tree-Assets" tilewidth="16" tileheight="16" tilecount="525" columns="21">
 <image source="../../graphics/Legacy-Fantasy - High Forest 2.3/Assets/Tree-Assets.png" width="336" height="400"/>
</tileset>
