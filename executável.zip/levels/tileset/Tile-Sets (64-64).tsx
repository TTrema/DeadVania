<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Tile-Sets (64-64)" tilewidth="64" tileheight="64" tilecount="30" columns="6">
 <image source="../../../Games/assets/Pirate Bomb/Sprites/8-Tile-Sets/Tile-Sets (64-64).png" width="384" height="320"/>
</tileset>
