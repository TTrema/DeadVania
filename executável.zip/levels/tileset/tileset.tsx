<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="tileset" tilewidth="32" tileheight="32" tilecount="169" columns="13">
 <image source="../../graphics/Medieval_Castle_Asset_Pack/Tiles/output/tileset.png" width="416" height="416"/>
</tileset>
