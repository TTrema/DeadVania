<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Mossy - FloatingPlatforms" tilewidth="16" tileheight="16" tilecount="16384" columns="128">
 <image source="../../../Games/assets/Mossy Tileset/Mossy - FloatingPlatforms.png" width="2048" height="2048"/>
</tileset>
