<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="bookshelf_1" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="../../graphics/Medieval_Castle_Asset_Pack/Decorations/bookshelf_1.png" width="64" height="77"/>
</tileset>
