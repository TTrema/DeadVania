<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="Terrain (32x32)" tilewidth="64" tileheight="64" tilecount="16" columns="8">
 <image source="../../../Games/assets/Treasure Hunters/Palm Tree Island/Sprites/Terrain/Terrain (32x32).png" width="544" height="160"/>
</tileset>
